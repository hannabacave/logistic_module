"""
Bifurcation diagram
============================

In this setion, you can see how plot the bifurcation diagram.
"""



from logistic_module.LogisticEquation.Bifurcation import Visualization_bifurcation
viz = Visualization_bifurcation()

viz.bifurcation_diagram()


